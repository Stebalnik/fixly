#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LATEST_DIR="$ROOT_DIR/snapshots/latest"
ARCHIVE_DIR="$ROOT_DIR/snapshots/archive"
TIMESTAMP="$(date +"%Y-%m-%d_%H-%M-%S")"
ARCHIVE_NAME="fixly-snapshot-${TIMESTAMP}.tar.gz"
ARCHIVE_PATH="$LATEST_DIR/$ARCHIVE_NAME"

cd "$ROOT_DIR"

mkdir -p "$LATEST_DIR" "$ARCHIVE_DIR"

find "$LATEST_DIR" -maxdepth 1 -type f -name "fixly-snapshot-*.tar.gz" -exec mv {} "$ARCHIVE_DIR"/ \;

write_project_tree() {
  {
    echo "# Project Tree"
    echo
    echo "Generated: $TIMESTAMP"
    echo
    find . \
      -path "./node_modules" -prune -o \
      -path "./.next" -prune -o \
      -path "./.git" -prune -o \
      -path "./snapshots/archive" -prune -o \
      -name ".env*" -prune -o \
      -print |
      sed 's#^\./##' |
      sort |
      sed 's#^$#.#'
  } > "$LATEST_DIR/PROJECT_TREE.md"
}

write_routes() {
  {
    echo "# App Routes"
    echo
    echo "Generated: $TIMESTAMP"
    echo
    if [ -d "src/app" ]; then
      find src/app -type f \
        \( -name "page.tsx" -o -name "layout.tsx" -o -name "route.ts" -o -name "loading.tsx" -o -name "not-found.tsx" -o -name "error.tsx" -o -name "template.tsx" -o -name "default.tsx" \) |
        sort
    else
      echo "src/app not found."
    fi
  } > "$LATEST_DIR/ROUTES.md"
}

write_changed_files() {
  {
    echo "# Changed Files"
    echo
    echo "Generated: $TIMESTAMP"
    echo
    echo "## git status --short"
    echo
    git status --short || true
    echo
    echo "## Last 5 Commits"
    echo
    git log -5 --oneline --decorate || true
  } > "$LATEST_DIR/CHANGED_FILES.md"
}

write_project_summary() {
  {
    echo "# Project Summary"
    echo
    echo "- Generated: $TIMESTAMP"
    echo "- Git branch: $(git branch --show-current 2>/dev/null || echo "unknown")"
    echo "- Commit: $(git rev-parse HEAD 2>/dev/null || echo "unknown")"
    echo
    echo "## Package Scripts"
    echo
    if [ -f "package.json" ]; then
      node - <<'NODE'
const fs = require("fs");
const pkg = JSON.parse(fs.readFileSync("package.json", "utf8"));
const scripts = pkg.scripts || {};
for (const [name, command] of Object.entries(scripts)) {
  console.log(`- \`${name}\`: \`${command}\``);
}
NODE
    else
      echo "package.json not found."
    fi
    echo
    echo "## Detected Env Keys"
    echo
    env_files="$(find . -maxdepth 2 -type f -name ".env*" \
      -not -path "./node_modules/*" \
      -not -path "./.next/*" \
      -not -path "./.git/*" \
      -not -path "./snapshots/*" | sort)"
    if [ -n "$env_files" ]; then
      while IFS= read -r env_file; do
        [ -n "$env_file" ] || continue
        echo
        echo "### ${env_file#./}"
        sed -n 's/^[[:space:]]*export[[:space:]]\{1,\}//; /^[[:space:]]*#/d; /^[[:space:]]*$/d; s/[[:space:]]*=.*$//p' "$env_file" |
          sed 's/^[[:space:]]*//; s/[[:space:]]*$//' |
          sort -u |
          sed 's/^/- `/' |
          sed 's/$/`/'
      done <<< "$env_files"
    else
      echo "No env files detected."
    fi
  } > "$LATEST_DIR/PROJECT_SUMMARY.md"
}

build_snapshot_archive() {
  local include_paths=()
  local candidate

  for candidate in \
    "src" \
    "supabase" \
    "scripts" \
    "public" \
    "package.json" \
    "pnpm-lock.yaml" \
    "tsconfig.json" \
    "next.config.ts" \
    "eslint.config.mjs" \
    "README.md" \
    "PROJECT_STATE.md" \
    "AGENTS.md" \
    "CLAUDE.md" \
    "snapshots/latest/PROJECT_TREE.md" \
    "snapshots/latest/ROUTES.md" \
    "snapshots/latest/CHANGED_FILES.md" \
    "snapshots/latest/PROJECT_SUMMARY.md"; do
    if [ -e "$candidate" ]; then
      include_paths+=("$candidate")
    fi
  done

  tar \
    --exclude="node_modules" \
    --exclude=".next" \
    --exclude=".git" \
    --exclude=".env" \
    --exclude=".env.*" \
    --exclude=".DS_Store" \
    --exclude="snapshots/archive" \
    -czf "$ARCHIVE_PATH" \
    "${include_paths[@]}"
}

write_project_tree
write_routes
write_changed_files
write_project_summary
build_snapshot_archive

echo "Created snapshot: $ARCHIVE_PATH"
