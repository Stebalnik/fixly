# Project Summary

- Generated: 2026-05-20_18-04-31
- Git branch: main
- Commit: 5e243f36a4cb59055281bdad0e8b0472d4dd717b

## Package Scripts

- `dev`: `next dev -p 4081`
- `build`: `NODE_OPTIONS='--max-old-space-size=4096' next build`
- `start`: `next start`
- `lint`: `eslint`
- `snapshot`: `bash scripts/snapshot.sh`
- `export:context`: `bash _project/scripts/export-project-context.sh`
- `geo:generate:country`: `node _project/scripts/generate-geonames-markets.mjs`
- `release`: `bash _project/scripts/release.sh`
- `geo:validate`: `node _project/scripts/validate-geo-relations.mjs`
- `geo:validate:all`: `node _project/scripts/validate-geo-relations.mjs --all`
- `geo:country`: `node _project/scripts/generate-and-validate-country.mjs`

## Detected Env Keys


### .env.example
- `GA_MEASUREMENT_PROTOCOL_SECRET`
- `INTERNAL_AI_AGENT_TOKEN`
- `NEXT_PUBLIC_GA_ID`
- `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`
- `NEXT_PUBLIC_SUPABASE_URL`
- `STRIPE_WEBHOOK_SECRET`
- `SUPABASE_DB_URL`
- `SUPABASE_SERVICE_ROLE_KEY`

### .env.local
- `BIGQUERY_TRENDS_COUNTRIES`
- `BIGQUERY_TRENDS_ENABLED`
- `BIGQUERY_TRENDS_LIMIT`
- `BIGQUERY_TRENDS_LOOKBACK_DAYS`
- `BIGQUERY_TRENDS_MAX_BYTES_PER_RUN`
- `BIGQUERY_TRENDS_MONTHLY_MAX_BYTES`
- `FIXLY_INTERNAL_CRON_SECRET`
- `GA_MEASUREMENT_PROTOCOL_SECRET`
- `GEMINI_API_KEY`
- `GEMINI_MODEL`
- `GOOGLE_CLOUD_PROJECT_ID`
- `GOOGLE_SEARCH_CONSOLE_CLIENT_ID`
- `GOOGLE_SEARCH_CONSOLE_CLIENT_SECRET`
- `GOOGLE_SEARCH_CONSOLE_REFRESH_TOKEN`
- `GOOGLE_SEARCH_CONSOLE_SITE_URL`
- `GROQ_API_KEY`
- `GROQ_MODEL`
- `INTERNAL_AI_AGENT_TOKEN`
- `INTERNAL_SEO_EXPANSION_COUNTRIES`
- `INTERNAL_SEO_EXPANSION_INCLUDE_SUBCATEGORIES`
- `INTERNAL_SEO_EXPANSION_LIMIT`
- `INTERNAL_SEO_EXPANSION_MAX_MARKETS_PER_COUNTRY`
- `LLM_ENABLED`
- `LLM_PROVIDER`
- `NEXT_PUBLIC_APP_URL`
- `NEXT_PUBLIC_GA_ID`
- `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`
- `NEXT_PUBLIC_SUPABASE_URL`
- `SERVICE_REQUESTS_PER_TOPIC`
- `SERVICE_REQUEST_GENERATOR_COUNTRIES`
- `SERVICE_REQUEST_GENERATOR_DAILY_MAX`
- `SERVICE_REQUEST_GENERATOR_LIMIT`
- `STRIPE_SECRET_KEY`
- `STRIPE_WEBHOOK_SECRET`
- `SUPABASE_DB_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `XAI_API_KEY`
- `XAI_MODEL`
