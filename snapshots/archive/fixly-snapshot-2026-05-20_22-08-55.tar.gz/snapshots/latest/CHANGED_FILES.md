# Changed Files

Generated: 2026-05-20_22-08-55

## Current Branch

main

## git status --short

 M src/app/api/customer/requests/[id]/unlock-pro/route.ts
 M src/app/api/requests/[id]/contact/route.ts
 M src/app/api/requests/[id]/unlock/route.ts
 M src/app/requests/[requestSlug]/page.tsx
 M src/app/requests/page.tsx
 M src/lib/ai-agents/request-generator-agent.ts
 M src/lib/fixa/index.ts
 M src/lib/seo/requestEnrichment.ts
?? .codex/
?? snapshots/
?? supabase/migrations/20260520192059_harden_lead_unlock_idempotency.sql
?? supabase/migrations/20260520214038_marketplace_core_atomic_fixa.sql

## Last 5 Commits

b809728f (HEAD -> main, origin/main, origin/HEAD) Add autonomous Supabase migration workflow
5e243f36 (tag: v1.22.0) release: v1.22.0
def6a118 (tag: v1.21.0) release: v1.21.0
39bac420 (tag: v1.20.0) release: v1.20.0
198677d0 (tag: v1.19.1) release: v1.19.1
