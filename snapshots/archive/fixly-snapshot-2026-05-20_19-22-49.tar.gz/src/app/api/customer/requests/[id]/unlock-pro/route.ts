import { NextResponse, type NextRequest } from "next/server";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import { getCurrentUser } from "@/lib/auth/account";
import { addFixaTransaction, getFixaBalance } from "@/lib/fixa";
import { createNotification } from "@/lib/notifications";

const CUSTOMER_PRO_UNLOCK_PRICE_FIXAS = 100;

type RouteContext = {
  params: Promise<{
    id: string;
  }>;
};

type ServiceRequestRow = {
  id: string;
  public_slug: string;
  customer_user_id: string;
  category_slug: string;
  subcategory_slug: string | null;
  market_slug: string;
  city: string;
  state: string;
  country_code: string;
  status: string;
  lead_status: string | null;
  purchase_count: number | null;
  max_purchases: number | null;
  max_responses: number | null;
};

function getMaxPurchases(
  serviceRequest: Pick<ServiceRequestRow, "max_purchases" | "max_responses">
) {
  return serviceRequest.max_purchases ?? serviceRequest.max_responses ?? null;
}

function getRequestUnavailableMessage(serviceRequest: ServiceRequestRow) {
  if (serviceRequest.status !== "open") {
    return "This request is no longer open for new contact unlocks.";
  }

  if (serviceRequest.lead_status && serviceRequest.lead_status !== "available") {
    if (serviceRequest.lead_status === "sold_out") {
      return "This request has reached its response limit.";
    }

    if (serviceRequest.lead_status === "closed") {
      return "This request is closed.";
    }

    return "This request is no longer available for new contact unlocks.";
  }

  const maxPurchases = getMaxPurchases(serviceRequest);

  if (
    maxPurchases !== null &&
    (serviceRequest.purchase_count ?? 0) >= maxPurchases
  ) {
    return "This request has reached its response limit.";
  }

  return null;
}

function isUniqueViolation(error: { code?: string } | null) {
  return error?.code === "23505";
}

export async function POST(request: NextRequest, context: RouteContext) {
  const user = await getCurrentUser();

  if (!user) {
    return NextResponse.json({ error: "Login required." }, { status: 401 });
  }

  const { id } = await context.params;

  const body = (await request.json()) as {
    proUserId?: string;
  };

  const proUserId = body.proUserId;

  if (!proUserId) {
    return NextResponse.json(
      { error: "Pro user ID is required." },
      { status: 400 }
    );
  }

  if (proUserId === user.id) {
    return NextResponse.json(
      { error: "You cannot unlock your own contact." },
      { status: 400 }
    );
  }

  const admin = createSupabaseAdminClient();

  const { data: serviceRequest, error: requestError } = await admin
    .from("service_requests")
    .select(
      `
      id,
      public_slug,
      customer_user_id,
      category_slug,
      subcategory_slug,
      market_slug,
      city,
      state,
      country_code,
      status,
      lead_status,
      purchase_count,
      max_purchases,
      max_responses
    `
    )
    .eq("id", id)
    .eq("customer_user_id", user.id)
    .maybeSingle();

  if (requestError) {
    return NextResponse.json(
      { error: "Unable to load request." },
      { status: 500 }
    );
  }

  if (!serviceRequest) {
    return NextResponse.json({ error: "Request not found." }, { status: 404 });
  }

  const typedServiceRequest = serviceRequest as ServiceRequestRow;

  const { data: existingAccess, error: existingAccessError } = await admin
    .from("customer_pro_contact_access")
    .select("id, price_fixas, created_at")
    .eq("request_id", typedServiceRequest.id)
    .eq("customer_user_id", user.id)
    .eq("pro_user_id", proUserId)
    .maybeSingle();

  if (existingAccessError) {
    return NextResponse.json(
      { error: "Unable to verify existing contact access." },
      { status: 500 }
    );
  }

  const { data: proLeadAccess, error: proLeadAccessError } = await admin
    .from("pro_lead_access")
    .select("id, purchased_at, price_fixas")
    .eq("request_id", typedServiceRequest.id)
    .eq("pro_user_id", proUserId)
    .maybeSingle();

  if (proLeadAccessError) {
    return NextResponse.json(
      { error: "Unable to verify pro access." },
      { status: 500 }
    );
  }

  if (!proLeadAccess) {
    return NextResponse.json(
      { error: "This pro has not opened your request." },
      { status: 403 }
    );
  }

  const isNewUnlock = !existingAccess;
  let customerBalanceAfter: number | null = null;

  if (isNewUnlock) {
    const unavailableMessage = getRequestUnavailableMessage(typedServiceRequest);

    if (unavailableMessage) {
      return NextResponse.json(
        { error: unavailableMessage },
        { status: 409 }
      );
    }

    const balance = await getFixaBalance(user.id);

    if (balance < CUSTOMER_PRO_UNLOCK_PRICE_FIXAS) {
      return NextResponse.json(
        { error: "Insufficient FIXA balance." },
        { status: 402 }
      );
    }

    const { error: accessError } = await admin
      .from("customer_pro_contact_access")
      .insert({
        request_id: typedServiceRequest.id,
        customer_user_id: user.id,
        pro_user_id: proUserId,
        price_fixas: CUSTOMER_PRO_UNLOCK_PRICE_FIXAS,
      });

    if (accessError) {
      if (isUniqueViolation(accessError)) {
        const { data: racedAccess } = await admin
          .from("customer_pro_contact_access")
          .select("id, price_fixas, created_at")
          .eq("request_id", typedServiceRequest.id)
          .eq("customer_user_id", user.id)
          .eq("pro_user_id", proUserId)
          .maybeSingle();

        if (racedAccess) {
          const { data: proProfile } = await admin
            .from("pro_profiles")
            .select("company_name, contact_name, contact_email, contact_phone")
            .eq("user_id", proUserId)
            .maybeSingle();

          return NextResponse.json({
            ok: true,
            alreadyUnlocked: true,
            priceFixas: 0,
            customerBalanceAfter: null,
            request: {
              id: typedServiceRequest.id,
              publicSlug: typedServiceRequest.public_slug,
              status: typedServiceRequest.status,
              leadStatus: typedServiceRequest.lead_status,
            },
            proContact: {
              companyName: proProfile?.company_name ?? "Fixly Pro",
              contactName: proProfile?.contact_name ?? "",
              email: proProfile?.contact_email ?? "",
              phone: proProfile?.contact_phone ?? "",
            },
          });
        }
      }

      return NextResponse.json(
        { error: "Unable to unlock this pro contact right now." },
        { status: 400 }
      );
    }

    try {
      customerBalanceAfter = await addFixaTransaction({
        userId: user.id,
        amount: -CUSTOMER_PRO_UNLOCK_PRICE_FIXAS,
        transactionType: "pro_contact_unlock",
        requestId: typedServiceRequest.id,
        relatedUserId: proUserId,
      });
    } catch (error) {
      await admin
        .from("customer_pro_contact_access")
        .delete()
        .eq("request_id", typedServiceRequest.id)
        .eq("customer_user_id", user.id)
        .eq("pro_user_id", proUserId);

      return NextResponse.json(
        {
          error:
            error instanceof Error
              ? error.message
              : "Unable to charge FIXAs for this contact unlock.",
        },
        { status: 402 }
      );
    }

    await createNotification({
      userId: proUserId,
      type: "pro_contact_unlocked",
      title: "A customer unlocked your contact",
      body: "A customer opened your pro contact details after you unlocked their request.",
      href: `/requests/${typedServiceRequest.public_slug}`,
      metadata: {
        requestId: typedServiceRequest.id,
        publicSlug: typedServiceRequest.public_slug,
        customerUserId: user.id,
        proUserId,
        categorySlug: typedServiceRequest.category_slug,
        subcategorySlug: typedServiceRequest.subcategory_slug,
        marketSlug: typedServiceRequest.market_slug,
        city: typedServiceRequest.city,
        state: typedServiceRequest.state,
        countryCode: typedServiceRequest.country_code,
      },
    });
  }

  const { data: proProfile, error: proProfileError } = await admin
    .from("pro_profiles")
    .select("company_name, contact_name, contact_email, contact_phone")
    .eq("user_id", proUserId)
    .maybeSingle();

  if (proProfileError) {
    return NextResponse.json(
      { error: "Unable to load pro contact." },
      { status: 500 }
    );
  }

  return NextResponse.json({
    ok: true,
    alreadyUnlocked: !isNewUnlock,
    priceFixas: isNewUnlock ? CUSTOMER_PRO_UNLOCK_PRICE_FIXAS : 0,
    customerBalanceAfter,
    request: {
      id: typedServiceRequest.id,
      publicSlug: typedServiceRequest.public_slug,
      status: typedServiceRequest.status,
      leadStatus: typedServiceRequest.lead_status,
    },
    proContact: {
      companyName: proProfile?.company_name ?? "Fixly Pro",
      contactName: proProfile?.contact_name ?? "",
      email: proProfile?.contact_email ?? "",
      phone: proProfile?.contact_phone ?? "",
    },
  });
}
